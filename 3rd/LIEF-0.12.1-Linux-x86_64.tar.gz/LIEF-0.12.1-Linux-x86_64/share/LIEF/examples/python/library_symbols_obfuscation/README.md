Presentation
============

The aim of this example is to show how we can change dynamic symbols in both
library and binary.

In the example we will change the symbol `add` to `abc` and the library name
`libadd.so` to `libabc.so`
