LIEF CMake Integration Example - add_subdirectory
=================================================


.. code-block:: console

  $ mkdir build
  $ cd build
  $ cmake ..
  $ make
  $ HelloLIEF /bin/ls # or explorer.exe or whatever

