LIEF CMake Integration Example - find_package()
===============================================


.. code-block:: console

  $ mkdir build
  $ cd build
  $ cmake -DLIEF_DIR=<PATH_TO_LIEF_INSTALL_DIR>/share/LIEF/cmake ..
  $ make
  $ HelloLIEF /bin/ls # or explorer.exe or whatever

